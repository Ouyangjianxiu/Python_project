# -*- coding: utf-8 -*-
import webbrowser

class Movie():
	def __init__(self, movie_title, movie_storyline, movie_image, movie_youtube):   #在init这个初始化函数中 函数主体的格式都是self.xxxx 
		self.title = movie_title
		self.storyline = movie_storyline
		self.poster_image_url = movie_image
		self.trailer_youtube_url = movie_youtube
		
	def show_trailer(self):
		webbrowser.open(self.trailer_youtube_url)    #模块名.xxxx(函数)
		
		