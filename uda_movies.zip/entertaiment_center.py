# -*- coding: utf-8 -*-
import uda5_media
import fresh_tomatoes
#toy_story = uda5_media.Movie("Toy Story",                     
                        #"A story of a boy and his toys that come to life",
						#"https://upload.wikimedia.org/wikipedia/en/1/13/Toy_Story.jpg",
						#"https://www.youtube.com/watch?v=vwyZH85NQC4")
#注意 这里的类不在这个文件里，因此 创建实例的时候要先打出类所在文件.类名

#print(toy_story.storyline)
#toy_story.show_trailer()    #这时toy_story这个对象已经存在，可以直接调用Movie类中的函数或者特征

avatar = uda5_media.Movie("Avatar",
                        "A marine on an alien planet",
						"https://en.wikipedia.org/wiki/Avatar#/media/File:Deshaavathaaram4_narasimham.jpg",
						"https://www.youtube.com/watch?v=dHRIVioj8l0")
						
#print(avatar.storyline)
#avatar.show_trailer()

the_holiday = uda5_media.Movie("The holiday",
                        "two lovelorn women from opposite sides of the Atlantic Ocean",
						"https://en.wikipedia.org/wiki/The_Holiday#/media/File:Theholidayposter.jpg",
						"https://www.youtube.com/watch?v=A6zpR9oXzEs")
						
love_actually = uda5_media.Movie("Love Actually",
                        " The story begins five weeks before Christmas and is played out in a weekly countdown until the holiday, followed by an epilogue that takes place one month later.",
						"https://en.wikipedia.org/wiki/Love_Actually#/media/File:Love_Actually_movie.jpg",
						"https://www.youtube.com/watch?v=B7u6bMBlCXw")
						

theory_of_everything = uda5_media.Movie("Theory of everything",
                        "the story of Jane Wilde Hawking",
						"https://en.wikipedia.org/wiki/The_Theory_of_Everything_(2014_film)#/media/File:Theory_of_Everything.jpg",
						"https://www.youtube.com/watch?v=Salz7uGp72c")
						
doctor_strange = uda5_media.Movie("Doctor Strange",
                        "the story of a new super hero",
						"https://en.wikipedia.org/wiki/Doctor_Strange_(film)#/media/File:Doctor_Strange_poster.jpg",
						"https://www.youtube.com/watch?v=HSzx-zryEgM")
						
fantastic_beasts = uda5_media.Movie("Fantastic Beasts and Where to Find Them",
                        "try to project the fantastic beasts",
						"https://en.wikipedia.org/wiki/Fantastic_Beasts_and_Where_to_Find_Them_(film)#/media/File:Fantastic_Beasts_and_Where_to_Find_Them_poster.png",
						"https://www.youtube.com/watch?v=Vso5o11LuGU")

						
movies = [avatar, the_holiday, love_actually, theory_of_everything, doctor_strange, fantastic_beasts]
fresh_tomatoes.open_movies_page(movies)						
						